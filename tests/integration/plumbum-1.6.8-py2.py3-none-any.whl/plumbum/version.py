version = (1, 6, 8)
version_string = ".".join(map(str, version))
release_date = "2019.10.30"
