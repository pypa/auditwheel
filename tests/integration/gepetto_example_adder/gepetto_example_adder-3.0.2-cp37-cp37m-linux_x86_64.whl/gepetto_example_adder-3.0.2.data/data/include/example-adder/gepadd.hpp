#ifndef __example_adder_gep_add__
#define __example_adder_gep_add__

namespace gepetto {
namespace example {
long add(const long a, const long b);
long sub(const long a, const long b);
}  // namespace example
}  // namespace gepetto

#endif
